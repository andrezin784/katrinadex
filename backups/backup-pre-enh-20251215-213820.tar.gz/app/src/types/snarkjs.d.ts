declare module 'snarkjs';








